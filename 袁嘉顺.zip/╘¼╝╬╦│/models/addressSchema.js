const mongoose = require('mongoose')
const userSchema = mongoose.Schema({
    type: Number,
    username: String,
    detail: String,
    telephone: String
}, { collection: 'address' })
const User = module.exports = mongoose.model('address', userSchema)