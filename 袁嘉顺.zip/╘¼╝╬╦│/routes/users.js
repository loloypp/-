//const { urlencoded } = require('express');
var express = require('express');
var path = require('path');
//const userSchema = require('../models/userSchema');
var router = express.Router();
let bodyParser = require('body-parser'); //cnpm install body-parser -S
// const { where } = require('../models/userSchema');
// const { path } = require('../app');
let urlencodedParser = bodyParser.urlencoded({ extended: false })
let userModel = require('./../models/userSchema')
    /* GET users listing. */
router.get('/', function(req, res, next) {
    // res.send('respond with a resource');
    res.sendFile(path.join(__dirname, '../views/login.html'))
});

//显示用户列表功能
router.get('/list', (req, res) => {
    // res.render('users',{ userlist:[] });
    // 第一步：
    // res.render('users',{ userlist:[{"username":"123","password":"456"}] });
    // 第二步:从数据库里查询出来
    userModel.find((err, result) => {
        //console.log(result)
        // {layout:false}
        res.render('users', { userlist: result })
    })
});






//添加功能
router.post('/add', urlencodedParser, (req, res) => {
    let where = { username: req.body.username }
    userModel.findOne(where, (err, result) => {
        if (result == null) {
            var duixiang = new userModel(req.body)
                //2、向数据库添加
            duixiang.save((err) => {
                if (err) throw err
                console.log("添加成功")
                userModel.find((err, result) => {
                    res.render('users', { userlist: result });
                })
            })
        } else {
            //返回注册页面  告知  
            res.redirect("/register")
        }
    })

    //1、添加的对象
    // var duixiang = new userModel(req.body)
    //     //2、向数据库添加
    // duixiang.save((err, result) => {
    //     if (err) throw err
    //     console.log("添加成功")
    //     res.redirect('users', { userlist: result });
    // })
})





//删除功能 根据id删除
router.post('/delete', urlencodedParser, (req, res) => {
    //1、添加的对象
    var where = { _id: require('mongodb').ObjectId(req.body._id) }
        //2、向数据库添加
    userModel.deleteOne(where, (err) => {
        if (err) throw err
        console.log("删除成功")

        userModel.find((err, result) => {
            res.render('users', { userlist: result })
        })
    })
})


//修改功能  根据id修改用户名  密码等信息
router.post('/update', urlencodedParser, (req, res) => {
    userModel.updateOne({ _id: req.body._id }, req.body, (err, result) => {
        if (err) throw err
        console.log('修改成功')
        userModel.find((err, result) => {
            res.render('users', { userlist: result });
        })
    })

})


//登录功能
router.post("/login", urlencodedParser, (req, res) => {
    let where = req.body
    userModel.findOne(where, (err, result) => {
        if (result == null) {
            console.log('查询失败')
            res.redirect('/')
        } else {
            console.log('查询成功')
            res.redirect('/home')
        }

    })

})

module.exports = router;