var express = require('express');
var router = express.Router();
let bodyParser = require('body-parser'); //cnpm install body-parser -S
let urlencodedParser = bodyParser.urlencoded({ extended: false })
let addressModel = require('./../models/addressSchema')


router.post('/add', urlencodedParser, (req, res) => {
    var duixiang = new addressModel(req.body)
    duixiang.save((err) => {
        if (err) throw err
        console.log("添加成功")
        addressModel.find((err, result) => {
            res.render('address', { addresslist: result, total: result.length });
        })
    })
})


router.post('/delete', urlencodedParser, (req, res) => {
    //1、添加的对象
    var where = { _id: require('mongodb').ObjectId(req.body._id) }
        //2、向数据库添加
    addressModel.deleteOne(where, (err) => {
        if (err) throw err
        console.log("删除成功")

        addressModel.find((err, result) => {
            res.render('address', { addresslist: result, total: result.length })
        })
    })
})


/* GET home page. */
router.get('/list', (req, res) => {
    addressModel.find((err, result) => {
        res.render('address', { addresslist: result, total: result.length });
    })
});

module.exports = router;